print("im gonna build a great wall")
shell.run(".menu.lua")
